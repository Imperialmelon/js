
import {ProductCardComponent} from "../../components/product-card/index.js";
import {ProductPage} from "../product/index.js";
import {HSE_page} from "../hse_page/index.js";
import {MSU_page} from "../msu_page/index.js";
import {BMSTU_page} from "../bmstu_page/index.js";
export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }
    get pageRoot() {
        return document.getElementById('main-page')
    }
    
    getData() {
        return [
            {
                id: 1,
                src: "https://blog.coursera.org/wp-content/uploads/2020/11/CAMPUS_exterior1-1-2048x1365.jpg",
                title: "ВШЭ",
                text: "Смотреть факультеты"
            },
            {
                id: 2,
                src: "https://sleeplab.ru/wp-content/uploads/2023/03/moskovskij-universitet.jpg",
                title: "МГУ",
                text: "Смотреть факультеты"
            },
            {
                id: 3,
                src: "https://ichinese8.ru/wp-content/uploads/2020/11/2-1-1024x731.jpg",
                title: "МГТУ",
                text: "Смотреть факультеты"
            },
        ]
    }

    getHTML() {
        return (
            `
                <div id="main-page" class="d-flex flex-wrap"><div/>
            `
        )
    }

    clickCard(e) {
        const cardId = e.target.dataset.id
        // const productPage = new ProductPage(this.parent, cardId)
        let productPage = 0;
        if(cardId == "1"){
            productPage = new HSE_page(this.parent, cardId)
        }
        if(cardId == 2){
            productPage = new MSU_page(this.parent, cardId)
        }
        if(cardId == 3){
            productPage = new BMSTU_page(this.parent, cardId)
        }
        productPage.render()
    }
    
    render() {
        this.parent.innerHTML = ''
        this.parent.innerHTML = "Дизайн"
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)
        
        const data = this.getData()
        data.forEach((item) => {
            const productCard = new ProductCardComponent(this.pageRoot)
            productCard.render(item, this.clickCard.bind(this))
        })
    }
}